import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

# Create tables
cur.execute("""
CREATE TABLE IF NOT EXISTS students(
    id INTEGER PRIMARY KEY,
    name TEXT,
    age INTEGER,
    marks REAL
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS courses(
    course_id INTEGER PRIMARY KEY,
    course_name TEXT,
    student_id INTEGER
)
""")

# Insert sample data
cur.execute("INSERT OR IGNORE INTO students VALUES(1, 'Naman', 20, 85)")
cur.execute("INSERT OR IGNORE INTO students VALUES(2, 'Taru', 21, 90)")
cur.execute("INSERT OR IGNORE INTO students VALUES(3, 'kaddu', 20, 75)")

cur.execute("INSERT OR IGNORE INTO courses VALUES(101, 'Python', 1)")
cur.execute("INSERT OR IGNORE INTO courses VALUES(102, 'Java', 2)")

con.commit()

# LEFT JOIN
cur.execute("""
SELECT students.name, courses.course_name
FROM students
LEFT JOIN courses
ON students.id = courses.student_id
""")

for row in cur.fetchall():
    print(row)

con.close()
