import sqlite3
import csv

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("SELECT * FROM students")
rows = cur.fetchall()

with open("students.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["ID", "Name", "Age", "Marks"])
    w.writerows(rows)

con.close()
print("Data exported to CSV")
