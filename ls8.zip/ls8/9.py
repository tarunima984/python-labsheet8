import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, name TEXT, age INTEGER, marks REAL)")

data = [
    (2, "diya", 21, 90),
    (3, "palak", 20, 75),
    (4, "tarua", 22, 95)
]

cur.executemany("INSERT INTO students VALUES(?, ?, ?, ?)", data)
con.commit()

print("Records inserted successfully")
con.close()
