import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("UPDATE students SET name='Kridhav' WHERE id=1")
con.commit()

print("Name updated successfully")
con.close()
