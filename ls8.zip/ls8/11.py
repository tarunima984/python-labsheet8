import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("SELECT name, marks FROM students")
print(cur.fetchall())

con.close()
