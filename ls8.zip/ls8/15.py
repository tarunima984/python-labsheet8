import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("SELECT * FROM students ORDER BY marks DESC LIMIT 3")

for row in cur.fetchall():
    print(row)

con.close()
