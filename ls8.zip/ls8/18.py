import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("DELETE FROM students WHERE id=3")
con.commit()

print("Record deleted successfully")
con.close()
