import sqlite3
import csv

con = sqlite3.connect("student.db")
cur = con.cursor()

with open("students.csv", "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        cur.execute(
            "INSERT OR REPLACE INTO students VALUES(?, ?, ?, ?)",
            (int(row["ID"]), row["Name"],
             int(row["Age"]), float(row["Marks"]))
        )

con.commit()
con.close()
print("CSV data imported")
