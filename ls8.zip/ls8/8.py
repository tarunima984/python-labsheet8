import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY, name TEXT, age INTEGER, marks REAL)")

cur.execute("INSERT INTO students VALUES(1, 'Naman Saini', 22, 85)")
con.commit()

print("Record inserted successfully")
con.close()
