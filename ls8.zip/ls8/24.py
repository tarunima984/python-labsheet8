import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("SELECT AVG(marks) FROM students")
print("Average marks:", cur.fetchone()[0])

con.close()
