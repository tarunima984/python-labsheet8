import sqlite3

con = sqlite3.connect("student.db")
print("Database connected successfully")
con.close()
