import sqlite3

def insert_data(con):
    con.execute(
        "INSERT OR REPLACE INTO students VALUES(5, 'Nomu', 21, 88)"
    )
    con.commit()
    print("Record inserted")

def fetch_data(con):
    for row in con.execute("SELECT * FROM students"):
        print(row)

con = sqlite3.connect("student.db")

insert_data(con)
fetch_data(con)

con.close()
