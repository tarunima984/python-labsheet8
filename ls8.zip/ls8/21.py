import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS courses(
    course_id INTEGER PRIMARY KEY,
    course_name TEXT,
    student_id INTEGER
)
""")

cur.execute("INSERT OR IGNORE INTO courses VALUES(101, 'Python', 1)")
cur.execute("INSERT OR IGNORE INTO courses VALUES(102, 'Java', 2)")

con.commit()
print("Courses created and data inserted")
con.close()
