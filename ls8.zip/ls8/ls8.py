Python 3.14.6 (tags/v3.14.6:c63aec6, Jun 10 2026, 10:26:10) [MSC v.1944 64 bit (AMD64)] on win32
Enter "help" below or click "Help" above for more information.

================ RESTART: C:/Users/hp/OneDrive/Documents/1.py ===============
Database connected successfully

================ RESTART: C:/Users/hp/OneDrive/Documents/2.py ===============
Database created successfully

================ RESTART: C:/Users/hp/OneDrive/Documents/3.py ===============
Table created successfully

================ RESTART: C:/Users/hp/OneDrive/Documents/4.py ===============
(0, 'id', 'INTEGER', 0, None, 1)
(1, 'name', 'TEXT', 0, None, 0)
(2, 'age', 'INTEGER', 0, None, 0)
(3, 'marks', 'REAL', 0, None, 0)

================ RESTART: C:/Users/hp/OneDrive/Documents/5.py ===============
[('students',)]

================ RESTART: C:/Users/hp/OneDrive/Documents/6.py ===============
[('students',)]

================ RESTART: C:\Users\hp\OneDrive\Documents\6.py ===============
Table deleted successfully

================ RESTART: C:/Users/hp/OneDrive/Documents/7.py ===============
Table does not exist

================ RESTART: C:/Users/hp/OneDrive/Documents/8.py ===============
Record inserted successfully

================ RESTART: C:/Users/hp/OneDrive/Documents/9.py ===============
Records inserted successfully

=============== RESTART: C:/Users/hp/OneDrive/Documents/10.py ===============
(1, 'Naman Saini', 22, 85.0)
(2, 'diya', 21, 90.0)
(3, 'palak', 20, 75.0)
(4, 'tarua', 22, 95.0)

=============== RESTART: C:/Users/hp/OneDrive/Documents/11.py ===============
[('Naman Saini', 85.0), ('diya', 90.0), ('palak', 75.0), ('tarua', 95.0)]

=============== RESTART: C:/Users/hp/OneDrive/Documents/12.py ===============
(1, 'Naman Saini', 22, 85.0)
(2, 'diya', 21, 90.0)
(4, 'tarua', 22, 95.0)

=============== RESTART: C:/Users/hp/OneDrive/Documents/13.py ===============
(4, 'tarua', 22, 95.0)
(2, 'diya', 21, 90.0)
(1, 'Naman Saini', 22, 85.0)
(3, 'palak', 20, 75.0)

=============== RESTART: C:/Users/hp/OneDrive/Documents/14.py ===============
Total records: 4

=============== RESTART: C:/Users/hp/OneDrive/Documents/15.py ===============
(4, 'tarua', 22, 95.0)
(2, 'diya', 21, 90.0)
(1, 'Naman Saini', 22, 85.0)

=============== RESTART: C:/Users/hp/OneDrive/Documents/16.py ===============
Marks updated successfully

=============== RESTART: C:/Users/hp/OneDrive/Documents/17.py ===============
Name updated successfully

=============== RESTART: C:/Users/hp/OneDrive/Documents/18.py ===============
Record deleted successfully

=============== RESTART: C:/Users/hp/OneDrive/Documents/19.py ===============
Low-scoring records deleted

=============== RESTART: C:/Users/hp/OneDrive/Documents/20.py ===============
Table emptied successfully

=============== RESTART: C:/Users/hp/OneDrive/Documents/21.py ===============
Courses created and data inserted

=============== RESTART: C:/Users/hp/OneDrive/Documents/22.py ===============

=============== RESTART: C:/Users/hp/OneDrive/Documents/22.py ===============

=============== RESTART: C:/Users/hp/OneDrive/Documents/23.py ===============

=============== RESTART: C:\Users\hp\OneDrive\Documents\22.py ===============
('Naman', 'Python')
('Taru', 'Java')

=============== RESTART: C:\Users\hp\OneDrive\Documents\23.py ===============
('Naman', 'Python')
('Taru', 'Java')
('kaddu', None)

=============== RESTART: C:/Users/hp/OneDrive/Documents/24.py ===============
Average marks: 83.33333333333333

=============== RESTART: C:/Users/hp/OneDrive/Documents/25.py ===============
(20, 2)
(21, 1)

=============== RESTART: C:/Users/hp/OneDrive/Documents/26.py ===============
Data exported to CSV

=============== RESTART: C:/Users/hp/OneDrive/Documents/27.py ===============
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/27.py", line 12, in <module>
    (int(row["id"]), row["name"],
KeyError: 'id'

=============== RESTART: C:/Users/hp/OneDrive/Documents/27.py ===============
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/27.py", line 12, in <module>
    (int(row["ID"]), row["name"],
KeyError: 'name'

=============== RESTART: C:/Users/hp/OneDrive/Documents/27.py ===============
Traceback (most recent call last):
  File "C:/Users/hp/OneDrive/Documents/27.py", line 13, in <module>
    int(row["age"]), float(row["marks"]))
KeyError: 'age'
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/27.py ===============
CSV data imported
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/28.py ===============
Database error: no such table: unknown_table
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/29.py ===============
Record inserted
(1, 'Naman', 20, 85.0)
(2, 'Taru', 21, 90.0)
(3, 'kaddu', 20, 75.0)
(5, 'Nomu', 21, 88.0)
>>> 
=============== RESTART: C:/Users/hp/OneDrive/Documents/30.py ===============

1. Add  2. View  3. Update  4. Delete  5. Exit
Enter choice: Delete
Invalid choice

1. Add  2. View  3. Update  4. Delete  5. Exit
Enter choice: 4
Enter ID: 3
Record deleted

1. Add  2. View  3. Update  4. Delete  5. Exit
Enter choice: 2
(1, 'Naman', 20, 85.0)
(2, 'Taru', 21, 90.0)
(5, 'Nomu', 21, 88.0)

1. Add  2. View  3. Update  4. Delete  5. Exit
Enter choice: 3
Enter ID: 1
Enter new marks: 90.1
Record updated

1. Add  2. View  3. Update  4. Delete  5. Exit
Enter choice: 5
