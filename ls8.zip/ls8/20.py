import sqlite3

con = sqlite3.connect("student.db")
cur = con.cursor()

cur.execute("DELETE FROM students")
con.commit()

print("Table emptied successfully")
con.close()
